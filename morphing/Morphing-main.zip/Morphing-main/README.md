# Animorphs Game

This is a 3D game based on the Animorphs series, built with the Godot Engine.

## Getting Started

To run this project, you will need to have Godot Engine (version 4.x or later) installed.

1.  Clone this repository.
2.  Open the Godot Engine editor.
3.  Click "Import" and select the `project.godot` file from this repository.
4.  Open the project and run the main scene.

## Deployment

This project is automatically deployed to GitHub Pages. You can access the latest version of the game at [your-github-username].github.io/animorphs-game/.